"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var DatePickerComponent = (function () {
    function DatePickerComponent() {
        // standard date and month format
        this.months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        this.totalDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    }
    DatePickerComponent.prototype.ngOnInit = function () {
        this.years = [];
        this.days = [];
        if (this.startYear > this.endYear) {
            this.startYear = this.endYear;
        }
        for (var i = this.endYear; i >= this.startYear; i--) {
            this.years.push(i);
        }
        if (this.monthFormat == "short") {
            console.log("Yo mahina", this.months);
            var tempMonth = [];
            // implement foreach
            for (var i = 0; i < this.months.length; i++) {
                tempMonth.push(this.months[i].substring(0, 3));
            }
            this.months = tempMonth;
        }
        // calls the default montsh
        this.onMonthChange(1);
    };
    // sets the days when months gets changed
    DatePickerComponent.prototype.onMonthChange = function (index) {
        this.days = [];
        for (var i = 1; i <= this.totalDays[index - 1]; i++) {
            this.days.push(i);
        }
    };
    DatePickerComponent.prototype.onYearChange = function (index) {
        // checks for the leap year
        if ((index % 400 == 0 || index % 100 != 0) && (index % 4 == 0)) {
            this.totalDays[1] = 29;
            console.log("Leap year");
        }
        else {
            this.totalDays[1] = 28;
            console.log("Not leap year");
        }
        this.onMonthChange(2);
    };
    return DatePickerComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], DatePickerComponent.prototype, "startYear", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], DatePickerComponent.prototype, "endYear", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], DatePickerComponent.prototype, "monthFormat", void 0);
DatePickerComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'datepicker',
        templateUrl: 'datepicker.component.html',
    }),
    __metadata("design:paramtypes", [])
], DatePickerComponent);
exports.DatePickerComponent = DatePickerComponent;
//# sourceMappingURL=datepicker.component.js.map